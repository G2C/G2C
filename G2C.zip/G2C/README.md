Gen2Coin - a Social currency like Bitcoin optimized for CPU mining using scrypt as a proof of work scheme.
 - 5 minute block targets
 - subsidy halves in 420k blocks (~4 years)
 - only 42,000,000 coins

The rest is the same as bitcoin.
 - 50 coins per block
 - 2016 blocks to retarget difficulty

Development process
===================

This is V1 it needs much development.
